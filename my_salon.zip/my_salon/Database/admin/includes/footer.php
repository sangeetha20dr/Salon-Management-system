<!--footer-->
    <div class="footer">
       <p>&copy; 2023 Men's Salon Management System Admin Panel || Created by Abhishek Singh</p>
    </div>
        <!--//footer-->